CALENDAR_CALLBACK = "CALENDAR"
JCALENDAR_CALLBACK = "JCALENDAR"

start_message = "Hey {}! I am calender bot \n \n Please type /calendar or /jcalendar to view my power"

calendar_message = "Please select a date: "
jcalendar_message = "لطفا تاریخی را انتخاب کنید:"

calendar_response_message = "You selected %s"
jcalendar_response_message = "شما تاریخ %s را انتخاب کردید"